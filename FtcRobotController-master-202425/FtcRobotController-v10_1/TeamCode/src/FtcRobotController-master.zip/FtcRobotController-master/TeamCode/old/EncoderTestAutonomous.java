package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name= "EncoderTestAutonomous", group="Autonomous")



public class EncoderTestAutonomous extends LinearOpMode
{
    static final double     COUNTS_PER_MOTOR_REV    = 1440 ;    // eg: TETRIX Motor AutoTemplate
    static final double     DRIVE_GEAR_REDUCTION    = 1.0 ;     // This is < 1.0 if geared UP
    static final double     WHEEL_DIAMETER_INCHES   = 4.0 ;     // For figuring circumference
    static final double     COUNTS_PER_INCH         = (COUNTS_PER_MOTOR_REV * DRIVE_GEAR_REDUCTION) / (WHEEL_DIAMETER_INCHES * 3.1415);
    private ElapsedTime runtime = new ElapsedTime();

    private DcMotor motorFrontRight;
    private DcMotor motorFrontLeft;
    private DcMotor motorBackRight;
    private DcMotor motorBackLeft;
    
    private Servo popperServo;
    private Servo planeServo;

    @Override
    public void runOpMode()
    {
        //Sets up motors for action once autonomous starts
        motorFrontRight = hardwareMap.dcMotor.get("FR");
        motorFrontLeft = hardwareMap.dcMotor.get("FL");
        motorBackLeft = hardwareMap.dcMotor.get("BL");
        motorBackRight = hardwareMap.dcMotor.get("BR");
        popperServo = hardwareMap.servo.get("POPS");
        planeServo = hardwareMap.servo.get("PLANE");

        motorBackLeft.setDirection(DcMotor.Direction.REVERSE);
        motorBackRight.setDirection(DcMotor.Direction.FORWARD);
        motorFrontLeft.setDirection(DcMotor.Direction.REVERSE);
        motorFrontRight.setDirection(DcMotor.Direction.FORWARD);

        telemetry.addData("Encoder front right", motorFrontRight.getCurrentPosition());
        telemetry.addData("Encoder front left", motorFrontLeft.getCurrentPosition());
        telemetry.addData("Encoder back right", motorBackRight.getCurrentPosition());
        telemetry.addData("Encoder back left", motorBackLeft.getCurrentPosition());
        telemetry.update();

        setupEncoders();

        // Wait until autonomous starts
        waitForStart();

        while (opModeIsActive())
        {
            telemetry.addData("Encoder front right", motorFrontRight.getCurrentPosition());
            telemetry.addData("Encoder front left", motorFrontLeft.getCurrentPosition());
            telemetry.addData("Encoder back right", motorBackRight.getCurrentPosition());
            telemetry.addData("Encoder back left", motorBackLeft.getCurrentPosition());
            telemetry.update();
            sleep(10);
        }
    }






    public void setupEncoders(){
        motorFrontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorFrontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorBackRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorBackLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        motorFrontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorFrontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorBackRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorBackLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }




    public void stopMotors(int time)
    {
        motorFrontRight.setPower(0.0);
        motorBackRight.setPower(0.0);
        motorFrontLeft.setPower(0.0);
        motorBackLeft.setPower(0.0);
        sleep(time);

    }




    public void strafePositionEncoders(int power, int position, boolean left, boolean right, int time){
        int newFrontLeftTarget = 0;
        int newBackLeftTarget = 0;
        int newFrontRightTarget = 0;
        int newBackRightTarget = 0;

        if(left == true) {
            newBackRightTarget = motorBackRight.getCurrentPosition() + (int) (-position * COUNTS_PER_INCH);
            newFrontRightTarget = motorFrontRight.getCurrentPosition() + (int) (position * COUNTS_PER_INCH);
            newBackLeftTarget = motorBackLeft.getCurrentPosition() + (int) (-position * COUNTS_PER_INCH);
            newFrontLeftTarget = motorFrontLeft.getCurrentPosition() + (int) (position * COUNTS_PER_INCH);
        } else if (right == true) {
            newBackRightTarget = motorBackRight.getCurrentPosition() + (int) (position * COUNTS_PER_INCH);
            newFrontRightTarget = motorFrontRight.getCurrentPosition() + (int) (-position * COUNTS_PER_INCH);
            newBackLeftTarget = motorBackLeft.getCurrentPosition() + (int) (position * COUNTS_PER_INCH);
            newFrontLeftTarget = motorFrontLeft.getCurrentPosition() + (int) (-position * COUNTS_PER_INCH);
        } else {
            telemetry.addData("Path", "these are the droids your looking for, go and fix the code");
        }

        motorFrontRight.setTargetPosition(newFrontRightTarget);
        motorBackRight.setTargetPosition(newBackRightTarget);
        motorFrontLeft.setTargetPosition(newFrontLeftTarget);
        motorBackLeft.setTargetPosition(newBackLeftTarget);

        motorFrontRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        motorFrontLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        motorBackRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        motorBackLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        runtime.reset();
        motorFrontRight.setPower(Math.abs(power));
        motorFrontLeft.setPower(Math.abs(power));
        motorBackRight.setPower(Math.abs(power));
        motorBackLeft.setPower(Math.abs(power));

        while (opModeIsActive() &&
                (runtime.seconds() < time) &&
                (motorBackLeft.isBusy() && motorFrontLeft.isBusy() && motorBackRight.isBusy() && motorFrontRight.isBusy())) {

            // Display it for the driver.
        }

        // Stop all motion;
        motorFrontRight.setPower(Math.abs(0));
        motorFrontLeft.setPower(Math.abs(0));
        motorBackRight.setPower(Math.abs(0));
        motorBackLeft.setPower(Math.abs(0));

        motorFrontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorFrontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorBackRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorBackLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }






    public void runPositionEncoders(double power, int leftPosition, int rightPosition, int time){
        int newLeftTarget = motorBackRight.getCurrentPosition() + (int)(leftPosition * COUNTS_PER_INCH);
        int newRightTarget = motorBackLeft.getCurrentPosition() + (int)(rightPosition * COUNTS_PER_INCH);

        motorFrontRight.setTargetPosition(newRightTarget);
        motorBackRight.setTargetPosition(newRightTarget);
        motorFrontLeft.setTargetPosition(newLeftTarget);
        motorBackLeft.setTargetPosition(newLeftTarget);

        motorFrontRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        motorFrontLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        motorBackRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        motorBackLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        runtime.reset();
        motorFrontRight.setPower(Math.abs(power));
        motorFrontLeft.setPower(Math.abs(power));
        motorBackRight.setPower(Math.abs(power));
        motorBackLeft.setPower(Math.abs(power));

        while (opModeIsActive() &&
                (runtime.seconds() < time) &&
                (motorBackLeft.isBusy() && motorFrontLeft.isBusy() && motorBackRight.isBusy() && motorFrontRight.isBusy())) {

            // Display it for the driver.
            telemetry.addData("Path1",  "Running to %7d, %7d", newLeftTarget,  newRightTarget);
            telemetry.addData("Path2",  "Running at %7d, %7d, %7d, %7d",
                    motorFrontRight.getCurrentPosition(),
                    motorFrontLeft.getCurrentPosition(),
                    motorBackRight.getCurrentPosition(),
                    motorBackLeft.getCurrentPosition());
            telemetry.update();
        }

        // Stop all motion;
        motorFrontRight.setPower(Math.abs(0));
        motorFrontLeft.setPower(Math.abs(0));
        motorBackRight.setPower(Math.abs(0));
        motorBackLeft.setPower(Math.abs(0));

        motorFrontRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorFrontLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorBackRight.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorBackLeft.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        motorFrontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorFrontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorBackRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorBackLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    }





}

